    <div class="box mt-3">
            <form action="<?php echo e(route('score.edit')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="hd_id" value="<?php echo e($data['id']); ?>">
                <div class="form-group mb-3">
                    <select required class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="score_give">
                        <option value="" disabled selected>Choose A Score</option>
                        <?php $__currentLoopData = $scores_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($score); ?>" <?php echo e(($data['score_number'] == $score ? "selected" : "")); ?>><?php echo e($score); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group mb-3">
                    <textarea name="note" class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Write your notes... (Optional)"><?php echo e($data['notes']); ?></textarea>
                </div>

                <?php if(!empty($data['score_files'])): ?>
                    <a style="color: #000;" class="btn btn-link" target="_blank" href="<?php echo e(asset('uploads/' . $data['score_files'])); ?>"> <?php echo e($data['score_files']); ?></a>
                <?php endif; ?>


                <input type="hidden" id="appl" name="appl" value="<?php echo e($data['applicant_id']); ?>">
                <input type="hidden" id="sub" name="sub" value="<?php echo e($data['subject_id']); ?>">
                <input type="hidden" id="crit_id" name="crit_id" value="<?php echo e($data['criteria_id']); ?>">

                <input style="display: none;" type="file" id="img-edit" name="image" class="form-control">

                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                    <a href="/delete/score/<?php echo e($data['id']); ?>" class="btn btn-danger btn-md" onclick="return confirm('Are you sure you want to delete this score?')">Delete</a>
                    <button type="button" class="btn btn-dark btn-md" onclick="selectPhotoEdit()">Add File</button>
                    <button type="submit" class="btn btn-dark btn-md">Update</button>
                </div>
            </form>
        </div>

        <script>
        function selectPhotoEdit() {
            $("#img-edit").trigger('click');
        }
        </script>
<?php /**PATH /Users/sumanta/Scoringapp-1/resources/views/scores/ajax_edit.blade.php ENDPATH**/ ?>