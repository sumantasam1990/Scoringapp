<?php echo $__env->make('layouts.header', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-6">

    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row">
        <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2"></div>
        <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-8">
            <div class="">
            <h2 class="display-4 text-left heading_txt"><?php echo e($user->name); ?></h2>
            <h5 style="margin-top: -5px;" class="display-7 text-left heading_txt">Dashboard</h5>

            <div class="mt-3">
                <a class="btn btn-success btn-sm" href="/create-subject">Add Subject</a>
                
            </div>

            

            <div class="row mt-6">
                <h4> Subjects</h4>
                <?php if(count($invited) > 0): ?>
                    <?php $__currentLoopData = $invited; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-4 mt-3">
                            <div class="card text-dark border-success" style="border: 6px solid green !important;">
                                <div class="card-body text-center">
                                <h5 class="card-title fw-bold mb-4 text-success" style="font-size: 22px;"><?php echo e($inv->subject_name); ?></h5>
                                
                                <a href="/create-scoring-sheet/<?php echo e($inv->id); ?>" class="btn btn-success btn-sm">Create Score Page</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p class="fw-bold">You don't have any subject.</p>
                <?php endif; ?>
            </div>


            </div>
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2"></div>
    </div>
</div>



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/sumanta/Scoringapp-1/resources/views/auth/dashboard.blade.php ENDPATH**/ ?>