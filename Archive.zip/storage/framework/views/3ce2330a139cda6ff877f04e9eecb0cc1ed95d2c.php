<div class="row">
    <div class="col-12">
        <?php if(session('msg')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <h4 class="alert-heading"><i class="bi bi-check2-circle"></i> Success!</h4>
                <strong><?php echo e(session('msg')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session('err')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h4 class="alert-heading"><i class="bi bi-info-circle"></i> Error!</h4>
                <strong><?php echo e(session('err')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /Users/sumanta/Scoringapp-1/resources/views/layouts/alert.blade.php ENDPATH**/ ?>